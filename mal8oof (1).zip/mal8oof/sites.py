"""Site list for mal8oof. To add a site, add one S(...) line.

S(name, profile_url, category, mode, **options)   ({u} = username)
  check_url        URL actually requested (e.g. a public API); default = profile_url
  not_found_codes  HTTP codes meaning "no such user" (default 404, 410)
Modes
  status        200 = found, not_found_codes = not found
  text_missing  200 = found, unless `missing_text` is in the page
  text_either   `found_text` in page = found, `missing_text` = not found, neither = UNCERTAIN
                (texts may be a string or a list; {u} is replaced by the username)
  json_null     JSON body null = not found      json_list   empty JSON list = not found
  json_bool     JSON object, `field` true = found, false = not found
  manual        site has a login wall / blocks scripts: no request is sent,
                result is UNCERTAIN and you open the link yourself
"""


def S(name, url, category, mode="status", **kw):
    return {"name": name, "url": url, "category": category, "mode": mode, **kw}


SOCIAL, GAMING, DEV, CREATIVE, OTHER = "Social", "Gaming", "Developer", "Creative", "Other"

SITES = [
    # --- Social ---
    S("Instagram", "https://www.instagram.com/{u}/", SOCIAL, "manual"),
    S("Facebook", "https://www.facebook.com/{u}", SOCIAL, "manual"),
    S("LinkedIn", "https://www.linkedin.com/in/{u}", SOCIAL, "manual"),
    S("X (Twitter)", "https://x.com/{u}", SOCIAL, "manual"),
    S("TikTok", "https://www.tiktok.com/@{u}", SOCIAL, "text_either",
      found_text='"uniqueId":"{u}"',
      missing_text=['"statusCode":10221', "Couldn't find this account"]),
    S("Snapchat", "https://www.snapchat.com/add/{u}", SOCIAL),
    S("Pinterest", "https://www.pinterest.com/{u}/", SOCIAL),
    S("Reddit", "https://www.reddit.com/user/{u}", SOCIAL,
      check_url="https://www.reddit.com/user/{u}/about.json"),
    S("YouTube", "https://www.youtube.com/@{u}", SOCIAL),
    S("Medium", "https://medium.com/@{u}", SOCIAL),
    # --- Gaming ---
    S("PlayStation (PSNProfiles)", "https://psnprofiles.com/{u}", GAMING),
    S("Steam", "https://steamcommunity.com/id/{u}", GAMING, "text_missing",
      missing_text="The specified profile could not be found"),
    S("Twitch", "https://www.twitch.tv/{u}", GAMING,
      check_url="https://passport.twitch.tv/usernames/{u}", not_found_codes=(204,)),
    S("Roblox", "https://www.roblox.com/user.aspx?username={u}", GAMING),
    S("Minecraft", "https://namemc.com/profile/{u}", GAMING,
      check_url="https://api.mojang.com/users/profiles/minecraft/{u}", not_found_codes=(204, 404)),
    S("Chess.com", "https://www.chess.com/member/{u}", GAMING,
      check_url="https://api.chess.com/pub/player/{u}"),
    S("Lichess", "https://lichess.org/@/{u}", GAMING, check_url="https://lichess.org/api/user/{u}"),
    # --- Developer ---
    S("GitHub", "https://github.com/{u}", DEV),
    S("GitLab", "https://gitlab.com/{u}", DEV, "json_list",
      check_url="https://gitlab.com/api/v4/users?username={u}"),
    S("Codeberg", "https://codeberg.org/{u}", DEV),
    S("Dev.to", "https://dev.to/{u}", DEV),
    S("Docker Hub", "https://hub.docker.com/u/{u}", DEV, check_url="https://hub.docker.com/v2/users/{u}/"),
    S("PyPI", "https://pypi.org/user/{u}/", DEV),
    S("npm", "https://www.npmjs.com/~{u}", DEV,
      check_url="https://registry.npmjs.org/-/user/org.couchdb.user:{u}"),
    S("Replit", "https://replit.com/@{u}", DEV),
    S("Kaggle", "https://www.kaggle.com/{u}", DEV),
    S("Hacker News", "https://news.ycombinator.com/user?id={u}", DEV, "json_null",
      check_url="https://hacker-news.firebaseio.com/v0/user/{u}.json"),
    S("TryHackMe", "https://tryhackme.com/p/{u}", DEV, "json_bool", field="exists",
      check_url="https://tryhackme.com/api/user/exist/{u}"),
    S("Pastebin", "https://pastebin.com/u/{u}", DEV),
    # --- Creative ---
    S("SoundCloud", "https://soundcloud.com/{u}", CREATIVE),
    S("Behance", "https://www.behance.net/{u}", CREATIVE),
    S("Vimeo", "https://vimeo.com/{u}", CREATIVE),
    S("Patreon", "https://www.patreon.com/{u}", CREATIVE),
    S("Linktree", "https://linktr.ee/{u}", CREATIVE),
    # --- Other ---
    S("Keybase", "https://keybase.io/{u}", OTHER),
    S("Gravatar", "https://gravatar.com/{u}", OTHER, check_url="https://en.gravatar.com/{u}.json"),
]

CATEGORIES = [SOCIAL, GAMING, DEV, CREATIVE, OTHER]
