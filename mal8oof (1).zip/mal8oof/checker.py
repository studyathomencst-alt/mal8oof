"""HTTP requests and result classification."""
import json
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from urllib.parse import quote, urlparse

import requests

FOUND, NOT_FOUND, UNCERTAIN = "FOUND", "NOT FOUND", "UNCERTAIN"

USERNAME_RE = re.compile(r"^[A-Za-z0-9._-]{3,30}$")
HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; mal8oof/2.0; educational OSINT tool)",
    "Accept-Language": "en-US,en;q=0.9",
}
LOGIN_HINTS = ("login", "signin", "sign-in", "sign_in", "/auth", "/accounts")


@dataclass
class Result:
    site: str
    category: str
    status: str
    url: str
    reason: str = ""
    manual: bool = False


def validate_username(username):
    """Return (True, '') or (False, reason)."""
    if not username:
        return False, "Username is empty."
    if len(username) < 3 or len(username) > 30:
        return False, "Username must be 3-30 characters."
    if not USERNAME_RE.match(username):
        return False, "Only letters, digits, dot, dash and underscore are allowed."
    return True, ""


def _texts(value, username):
    values = [value] if isinstance(value, str) else (value or [])
    return [v.replace("{u}", username).lower() for v in values]


def _classify(site, resp, username):
    """Turn an HTTP response into (status, reason)."""
    code = resp.status_code
    mode = site.get("mode", "status")

    if resp.history and any(h in urlparse(resp.url).path.lower() for h in LOGIN_HINTS):
        return UNCERTAIN, "login required"
    if code == 429:
        return UNCERTAIN, "rate limited"
    if code in (401, 403, 999):
        return UNCERTAIN, "blocked / login required"
    if code >= 500:
        return UNCERTAIN, f"server error {code}"
    if code in site.get("not_found_codes", (404, 410)):
        return NOT_FOUND, ""
    if code != 200:
        return UNCERTAIN, f"unexpected status {code}"

    if mode == "status":
        return FOUND, ""
    page = resp.text.lower()
    if mode == "text_missing":
        hit = any(t in page for t in _texts(site["missing_text"], username))
        return (NOT_FOUND if hit else FOUND), ""
    if mode == "text_either":
        if any(t in page for t in _texts(site["found_text"], username)):
            return FOUND, ""
        if any(t in page for t in _texts(site["missing_text"], username)):
            return NOT_FOUND, ""
        return UNCERTAIN, "page not recognised (possible bot block)"
    if mode in ("json_null", "json_list", "json_bool"):
        try:
            data = json.loads(resp.text)
        except ValueError:
            return UNCERTAIN, "unreadable response"
        if mode == "json_null":
            return (NOT_FOUND if data is None else FOUND), ""
        if mode == "json_list":
            if not isinstance(data, list):
                return UNCERTAIN, "unexpected response"
            return (FOUND if data else NOT_FOUND), ""
        if isinstance(data, dict) and site["field"] in data:
            return (FOUND if data[site["field"]] else NOT_FOUND), ""
        return UNCERTAIN, "unexpected response"
    return UNCERTAIN, "unknown check mode"


def check_site(site, username, timeout=10, delay=0.0, retries=1, get=requests.get):
    u = quote(username, safe="")
    profile = site["url"].format(u=u)
    cat = site.get("category", "")
    if site.get("mode") == "manual":
        return Result(site["name"], cat, UNCERTAIN, profile,
                      "login wall - open the link to check manually", manual=True)

    target = site.get("check_url", site["url"]).format(u=u)
    for attempt in range(retries + 1):
        if delay:
            time.sleep(delay)
        try:
            resp = get(target, headers=HEADERS, timeout=timeout, allow_redirects=True)
        except requests.Timeout:
            status, reason = UNCERTAIN, "timeout"
        except requests.RequestException:
            status, reason = UNCERTAIN, "connection error"
        else:
            status, reason = _classify(site, resp, username)
            if reason != "rate limited":
                break
        if attempt < retries:
            time.sleep(1.5 * (attempt + 1))      # back off, then retry once
    return Result(site["name"], cat, status, profile, reason)


def check_username(username, sites, timeout=10, delay=0.5, workers=4, retries=1,
                   progress=None, get=requests.get):
    """Check one username on every site. Results keep the site-list order."""
    out = [None] * len(sites)
    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        futures = {pool.submit(check_site, s, username, timeout, delay, retries, get): i
                   for i, s in enumerate(sites)}
        for n, fut in enumerate(as_completed(futures), 1):
            out[futures[fut]] = fut.result()
            if progress:
                progress(n, len(sites))
    return out
