#!/usr/bin/env python3
"""mal8oof - OSINT Username Investigator.

Examples
  python main.py                      interactive menu
  python main.py -u johndoe123        one username
  python main.py -u alice bob --json  several usernames + JSON report
  python main.py -f names.txt         usernames from a file (one per line)
"""
import argparse
import sys

from checker import check_username, validate_username
from report import ETHICS, now, open_links, print_report, save_html, save_reports
from sites import CATEGORIES, SITES

MAX_BATCH = 25


def read_file(path):
    with open(path, encoding="utf-8") as fh:
        return [l.strip() for l in fh if l.strip() and not l.startswith("#")]


def select_sites(args):
    sites = SITES
    if args.category:
        wanted = {c.lower() for c in args.category}
        sites = [s for s in sites if s["category"].lower() in wanted]
    if args.only:
        wanted = {n.lower() for n in args.only}
        sites = [s for s in sites if s["name"].lower() in wanted or s["name"].split()[0].lower() in wanted]
    if args.skip:
        banned = {n.lower() for n in args.skip}
        sites = [s for s in sites if s["name"].lower() not in banned and s["name"].split()[0].lower() not in banned]
    return sites


def show_progress(done, total):
    print(f"\r  checked {done}/{total}", end="\n" if done == total else "", flush=True)


def run(usernames, args):
    sites = select_sites(args)
    if not sites:
        print("[!] No sites match your --category/--only/--skip options.")
        return False
    valid = []
    for name in dict.fromkeys(usernames):          # remove duplicates, keep order
        ok, why = validate_username(name)
        if ok:
            valid.append(name)
        else:
            print(f"[!] Skipping '{name}': {why}")
    if len(valid) > MAX_BATCH:
        print(f"[!] Limiting to the first {MAX_BATCH} usernames.")
        valid = valid[:MAX_BATCH]

    for name in valid:
        print(f"\nChecking '{name}' on {len(sites)} sites ...")
        results = check_username(name, sites, args.timeout, args.delay, args.workers,
                                 args.retries, show_progress)
        checked = now()
        print_report(name, results, checked, color=not args.no_color, found_only=args.found_only)
        for p in save_reports(name, results, checked, args.out_dir, args.json):
            print(f"Saved: {p}")
        if args.html:
            print(f"Saved: {save_html(name, results, checked, args.out_dir)}")
        if args.open:
            print(f"Opened {open_links(results)} links in your browser.")
    return bool(valid)


def list_sites():
    for cat in CATEGORIES:
        print(f"\n{cat}:")
        for s in SITES:
            if s["category"] == cat:
                tag = "  (manual check)" if s["mode"] == "manual" else ""
                print(f"  - {s['name']}{tag}")


def accept_ethics(args):
    print(ETHICS)
    if args.yes:
        return True
    return input("Type 'yes' to confirm responsible use: ").strip().lower() == "yes"


def interactive(args):
    while True:
        print("\n1) Check one username\n2) Check several (comma separated)\n"
              "3) Check usernames from a file\n4) List sites\n0) Exit")
        choice = input("> ").strip()
        if choice == "0":
            return
        if choice == "4":
            list_sites()
        elif choice in ("1", "2"):
            raw = input("Username(s): ")
            names = [n.strip() for n in raw.split(",")] if choice == "2" else [raw.strip()]
            if not run(names, args):
                print("No valid username entered, try again.")
        elif choice == "3":
            try:
                run(read_file(input("File path: ").strip()), args)
            except OSError as e:
                print(f"[!] Cannot read file: {e}")
        else:
            print("Invalid choice.")


def main():
    p = argparse.ArgumentParser(description="mal8oof - OSINT Username Investigator")
    p.add_argument("-u", "--username", nargs="+", help="one or more usernames")
    p.add_argument("-f", "--file", help="text file with one username per line")
    p.add_argument("--json", action="store_true", help="also save a JSON report")
    p.add_argument("--timeout", type=float, default=10, help="seconds per request (default 10)")
    p.add_argument("--delay", type=float, default=0.5, help="pause before each request (default 0.5)")
    p.add_argument("--workers", type=int, default=4, help="parallel requests (default 4)")
    p.add_argument("--out-dir", default="reports", help="report folder (default: reports)")
    p.add_argument("--category", nargs="+", metavar="CAT",
                   help="only these categories: " + ", ".join(CATEGORIES))
    p.add_argument("--only", nargs="+", metavar="SITE", help="only these sites, e.g. github tiktok")
    p.add_argument("--skip", nargs="+", metavar="SITE", help="skip these sites")
    p.add_argument("--retries", type=int, default=1, help="retries on timeout/rate limit (default 1)")
    p.add_argument("--found-only", action="store_true", help="show only FOUND sites on screen")
    p.add_argument("--html", action="store_true", help="also save an HTML report with clickable links")
    p.add_argument("--open", action="store_true", help="open FOUND/UNCERTAIN links in your browser")
    p.add_argument("--no-color", action="store_true", help="disable coloured output")
    p.add_argument("--yes", action="store_true", help="skip the ethics confirmation")
    p.add_argument("--list-sites", action="store_true", help="show supported sites and exit")
    args = p.parse_args()

    if args.list_sites:
        list_sites()
        return 0
    if not accept_ethics(args):
        print("Cancelled.")
        return 1

    names = list(args.username or [])
    try:
        if args.file:
            names += read_file(args.file)
    except OSError as e:
        print(f"[!] Cannot read file: {e}")
        return 1

    if names:
        return 0 if run(names, args) else 1
    interactive(args)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nStopped.")
