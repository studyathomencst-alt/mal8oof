# mal8oof – OSINT Username Investigator

Checks whether one username has a public profile on 36 well-known sites in 5 categories (Social, Gaming, Developer, Creative, Other) and saves a short report.
Results per site: **FOUND**, **NOT FOUND**, or **UNCERTAIN** (blocked, rate-limited, login wall, timeout).

## Install
    pip install -r requirements.txt

## Use
    python main.py                       # interactive menu
    python main.py -u johndoe123         # one username
    python main.py -u alice bob --json   # several + JSON report
    python main.py -f names.txt          # file, one username per line (# = comment)
    python main.py --list-sites
    python main.py -u johndoe123 --category gaming social
    python main.py -u johndoe123 --only github tiktok --found-only

Links: every report ends with a **LINKS TO OPEN** list. `--html` saves a clickable report, `--open` opens the links in your browser.

Options: `--html  --open  --timeout 10  --delay 0.5  --workers 4  --retries 1  --category  --only  --skip  --found-only  --json  --out-dir reports  --no-color  --yes`

Reports go to `reports/` as `.txt` (and `.json` with `--json`).

## Files
| File | Role |
|---|---|
| main.py | menu, arguments, ethics notice |
| sites.py | site list (add a dict to add a site) |
| checker.py | validation, HTTP requests, classification |
| report.py | screen output, TXT/JSON reports |

## Responsible use
Only public pages are requested; no login or private data. Use on your own usernames or with permission.
A match does **not** prove the same person owns the accounts. UNCERTAIN means the site did not give a clear answer.

## Sites that need a manual check
Instagram, Facebook, LinkedIn and X put profiles behind a login wall and block scripts, so a reliable automatic
check is not possible without logging in (which this tool deliberately never does). They are shown as UNCERTAIN
with a link so you can open the page yourself. TikTok, PlayStation (via PSNProfiles) and a few others may
also return UNCERTAIN when the site blocks automated requests. This is expected and is reported honestly.
