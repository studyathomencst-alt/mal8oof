"""Screen output and saved reports (TXT / JSON)."""
import html
import json
import os
import webbrowser
from datetime import datetime

from checker import FOUND, NOT_FOUND, UNCERTAIN

try:
    from colorama import Fore, Style, init
    init()
    HAVE_COLOR = True
except ImportError:
    HAVE_COLOR = False

DISCLAIMER = "Note: a match does NOT prove the same person owns the accounts."
SYMBOL = {FOUND: "[+]", NOT_FOUND: "[-]", UNCERTAIN: "[?]"}
ETHICS = """\
RESPONSIBLE USE NOTICE
 - Use this tool only on usernames you own, or with permission / for lawful research.
 - It only checks public profile pages. No login, no private data.
 - Results are leads, not proof. Never harass, stalk or accuse anyone.
"""


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def summary(results):
    return (sum(r.status == FOUND for r in results),
            sum(r.status == NOT_FOUND for r in results),
            sum(r.status == UNCERTAIN for r in results))


def banner():
    return "=" * 32 + "\n MAL8OOF - USERNAME INVESTIGATOR\n" + "=" * 32


def result_line(r):
    if r.status == FOUND:
        extra = r.url
    elif r.status == UNCERTAIN:
        extra = f"{r.url}  ({r.reason})"
    else:
        extra = ""
    return f"{SYMBOL[r.status]} {r.site:<26} {r.status:<10} {extra}".rstrip()


def build_text(username, results, checked, found_only=False):
    f, n, u = summary(results)
    manual = sum(r.manual for r in results)
    lines = [banner(), f"Username: {username}   Checked: {checked}"]
    last = None
    for r in results:
        if found_only and r.status != FOUND:
            continue
        if r.category != last:
            lines += ["", f"-- {r.category} --"]
            last = r.category
        lines.append(result_line(r))
    lines += ["", f"Possible matches: {f}  Not found: {n}  Uncertain: {u}"]
    links = [x for x in results if x.status in (FOUND, UNCERTAIN)]
    if links:
        lines += ["", "LINKS TO OPEN (profile pages for this username):"]
        lines += [f"  {x.site}: {x.url}" + ("   <- check manually" if x.status == UNCERTAIN else "")
                  for x in links]
    if manual:
        lines.append(f"Manual check needed: {manual} (login-wall sites, open the links yourself)")
    lines.append(DISCLAIMER)
    return "\n".join(lines)


def print_report(username, results, checked, color=True, found_only=False):
    text = build_text(username, results, checked, found_only)
    if not (color and HAVE_COLOR):
        print(text)
        return
    colors = {"[+]": Fore.GREEN, "[-]": Fore.RED, "[?]": Fore.YELLOW}
    for line in text.splitlines():
        print(colors.get(line[:3], "") + line + Style.RESET_ALL)


def save_reports(username, results, checked, out_dir="reports", as_json=False):
    """Saved reports always list every site (found_only affects the screen only)."""
    os.makedirs(out_dir, exist_ok=True)
    base = os.path.join(out_dir, f"mal8oof_{username}_{datetime.now():%Y%m%d_%H%M%S}")
    paths = [base + ".txt"]
    with open(paths[0], "w", encoding="utf-8") as fh:
        fh.write(build_text(username, results, checked) + "\n")
    if as_json:
        f, n, u = summary(results)
        data = {"tool": "mal8oof", "username": username, "checked": checked,
                "summary": {"found": f, "not_found": n, "uncertain": u},
                "results": [r.__dict__ for r in results], "disclaimer": DISCLAIMER}
        paths.append(base + ".json")
        with open(paths[1], "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
    return paths


def save_html(username, results, checked, out_dir="reports"):
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"mal8oof_{username}_{datetime.now():%Y%m%d_%H%M%S}.html")
    rows = []
    for x in results:
        link = (f'<a href="{html.escape(x.url)}" target="_blank" rel="noopener">{html.escape(x.url)}</a>'
                if x.status in (FOUND, UNCERTAIN) else "")
        rows.append(f"<tr><td>{html.escape(x.category)}</td><td>{html.escape(x.site)}</td>"
                    f"<td>{x.status}</td><td>{link}</td><td>{html.escape(x.reason)}</td></tr>")
    page = ("<!doctype html><meta charset='utf-8'><title>mal8oof report</title>"
            "<style>body{font-family:sans-serif;margin:2em}td,th{border:1px solid #ccc;padding:6px 10px}"
            "table{border-collapse:collapse}</style>"
            f"<h2>mal8oof - {html.escape(username)}</h2><p>Checked: {checked}</p>"
            "<table><tr><th>Category</th><th>Site</th><th>Result</th><th>Link</th><th>Note</th></tr>"
            + "".join(rows) + f"</table><p><i>{DISCLAIMER}</i></p>")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(page)
    return path


def open_links(results, limit=15):
    """Open FOUND and UNCERTAIN profile links in the default browser."""
    links = [x.url for x in results if x.status in (FOUND, UNCERTAIN)][:limit]
    for url in links:
        webbrowser.open_new_tab(url)
    return len(links)
